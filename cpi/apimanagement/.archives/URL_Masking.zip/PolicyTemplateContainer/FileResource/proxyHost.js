// Set the proxy host into context variable 
setProxyHost();
