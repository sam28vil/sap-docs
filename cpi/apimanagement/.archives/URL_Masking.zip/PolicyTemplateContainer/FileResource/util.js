//Sets the proxy host in the proxyendpoint preflow so that it can be used later on
function setProxyHost(){
  var basepath = context.getVariable("proxy.basepath");
  var host = context.proxyRequest.headers['host'];

  context.setVariable("apim.proxyHost", host + basepath);

}

//Escapes the characters of regex use
function escapeRegExp(value) {
    return value.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
}

//Trims the last chars from the string
function trimEnd(value, searchChar){
  if (value.charAt(value.length - 1) == searchChar) {
    value = value.substr(0, value.length - 1);
  }
  return value;
}

//Returns the target end host and port from the target url
function getTargetHost(){
  const virtualhost = context.getVariable("sapapim.virtualhost");
  const virtualport = context.getVariable("sapapim.virtualport");
  
  return virtualhost + ':' + virtualport + '/sap/opu/odata/sap/ZGW_SO_ATEM_SRV';
}

//Returns the proxy host from the context variable
function getProxyHost(){
  return context.getVariable("apim.proxyHost");
}

//Returns the target base path by escaping the trailing /
function getTargetBasePath(){
  return trimEnd(context.getVariable("target.basepath"),'/');
}

//Returns the proxy base path by escaping the trailing /
function getProxyBasePath(){
  return trimEnd(context.getVariable("proxy.basepath"),'/');
}